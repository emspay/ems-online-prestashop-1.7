<?php

require_once(_PS_MODULE_DIR_ . '/ingpsp/ing-php/vendor/autoload.php');

class ingpspValidationModuleFrontController extends ModuleFrontController 
{

}
