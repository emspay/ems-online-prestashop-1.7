<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpsp}prestashop>ingpsp_5fb2baa143b10d64460fa57666d6abe5'] = 'ING PSP';
$_MODULE['<{ingpsp}prestashop>ingpsp_49879354a8ea9c94584e9ce7d3bcd2ff'] = 'Akzeptieren Sie Zahlungen für Ihre Produkte mit ING PSP. Installiere dieses Modul zuerst.';
$_MODULE['<{ingpsp}prestashop>ingpsp_cbe0a99684b145e77f3e14174ac212e3'] = 'Sind Sie über das Entfernen dieser Details sicher?';
$_MODULE['<{ingpsp}prestashop>ingpsp_a02758d758e8bec77a33d7f392eb3f8a'] = 'Keine Währung ist für dieses Modul eingestellt worden. Sie können das einstellen in das Localization / Currencies Menu.';
$_MODULE['<{ingpsp}prestashop>ingpsp_d45643f729d7f403fc99195d167b7dca'] = 'API Schlüssel ist erforderlich.';
$_MODULE['<{ingpsp}prestashop>ingpsp_dd418c402d9df2f5c9cee38c60c6a2a3'] = 'ING PSP Produkt ist erforderlich.';
$_MODULE['<{ingpsp}prestashop>ingpsp_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert.';
$_MODULE['<{ingpsp}prestashop>ingpsp_b09c67977572a1f9c8bea1f92a388d4b'] = 'ING PSP Einstellungen';
$_MODULE['<{ingpsp}prestashop>ingpsp_a1fa27779242b4902f7ae3bdd5c6d508'] = 'ING PSP Produkt';
$_MODULE['<{ingpsp}prestashop>ingpsp_7e858f7ae99f1431164a22973eb6ffda'] = 'Kassa Compleet';
$_MODULE['<{ingpsp}prestashop>ingpsp_081d60287de236d7f50b78b00ffa4c34'] = 'ING Checkout';
$_MODULE['<{ingpsp}prestashop>ingpsp_f2a534d504f841d76bf87e1a227db34d'] = 'ING ePay';
$_MODULE['<{ingpsp}prestashop>ingpsp_72050a2fc6b64df39833fe4f0268a334'] = 'Löst Frage, wenn curl.cacert Pfad nicht in PHP.ini eingestellt wird.';
$_MODULE['<{ingpsp}prestashop>ingpsp_deb7cb91dd8a3c49c3ee67d71355a561'] = 'cURL CA bündel benutzen.';
$_MODULE['<{ingpsp}prestashop>ingpsp_16192b8b71d2a73adc7a335f0cf4c9e2'] = 'Generiere automatisch eine Webhook URL an die API';
$_MODULE['<{ingpsp}prestashop>ingpsp_f095af35c2433074509597c4c828f879'] = 'Füge eine Webhook URL zu jeder Bestellung';
$_MODULE['<{ingpsp}prestashop>ingpsp_d876ff8da67c3731ae25d8335a4168b4'] = 'API Schlüssel';
$_MODULE['<{ingpsp}prestashop>ingpsp_c33550a3e5e97c7f4bc6552f37e96c97'] = 'Test API Schlüssel';
$_MODULE['<{ingpsp}prestashop>ingpsp_5bb461e1983e238ff34a2256eaea6ef7'] = 'Der Test-API Key ist nur für Klarna. Entfernen, wenn sie nicht verwendet wird.';
$_MODULE['<{ingpsp}prestashop>ingpsp_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{ingpsp}prestashop>errors-messages_8e488562a0a85e303af4b1713b9a932e'] = 'Leider ist ein Fehler bei der Verarbeitung Ihrer Bezahlung aufgetreten.';
$_MODULE['<{ingpsp}prestashop>errors-messages_471602b1e82c261e19506cfc74b89716'] = 'Leider ist ein Fehler bei der Verarbeitung Ihrer Bezahlung aufgetreten.';
$_MODULE['<{ingpsp}prestashop>errors-messages_34e0a062726d06e24047764c3bef28c0'] = 'Bitte klicken Sie hier noch einmal zu versuchen.';
$_MODULE['<{ingpsp}prestashop>pending_68a489dbc8079a40832c3d558fcfb069'] = 'Ihre Bestellung bei %s';
$_MODULE['<{ingpsp}prestashop>pending_59a536eff179c44dff6f4a87057acc68'] = 'Wir haben noch keine Bestätigung von Ihrem Bank oder Kartenaussteller erhalten.';
$_MODULE['<{ingpsp}prestashop>pending_d8512d09788452018a064169d2363ca3'] = 'Sie erhalten eine Nachricht, sobald wir dies entfangen haben.';
$_MODULE['<{ingpsp}prestashop>pending_b1193e98dc69a11033057672c190cc85'] = 'Kehren Sie zurück zur Kassa.';
$_MODULE['<{ingpsp}prestashop>processing_68a489dbc8079a40832c3d558fcfb069'] = 'Ihre Bestellung bei %s';
$_MODULE['<{ingpsp}prestashop>processing_8b792b5d9eedc14ed033c964f4cb6023'] = 'Bitte warten Sie, während Ihr Bestellstatus überprüft wird.';

