<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpsp}prestashop>ingpsp_5fb2baa143b10d64460fa57666d6abe5'] = 'ING PSP';
$_MODULE['<{ingpsp}prestashop>ingpsp_49879354a8ea9c94584e9ce7d3bcd2ff'] = 'Acceptez les versements pour vos produits utilisant ING PSP. Installez d\'abord ce module.';
$_MODULE['<{ingpsp}prestashop>ingpsp_cbe0a99684b145e77f3e14174ac212e3'] = 'Êtes-vous sûr de supprimer ces détails?';
$_MODULE['<{ingpsp}prestashop>ingpsp_a02758d758e8bec77a33d7f392eb3f8a'] = 'Aucune devise a été définie pour ce module. S\'il vous plaît configurer ce dans le menu Localisations / section Currencies.';
$_MODULE['<{ingpsp}prestashop>ingpsp_d45643f729d7f403fc99195d167b7dca'] = 'La clé API doit être définie.';
$_MODULE['<{ingpsp}prestashop>ingpsp_dd418c402d9df2f5c9cee38c60c6a2a3'] = 'Type de produit doit être définie.';
$_MODULE['<{ingpsp}prestashop>ingpsp_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour.';
$_MODULE['<{ingpsp}prestashop>ingpsp_b09c67977572a1f9c8bea1f92a388d4b'] = 'ING PSP Paramètres';
$_MODULE['<{ingpsp}prestashop>ingpsp_a1fa27779242b4902f7ae3bdd5c6d508'] = 'ING PSP Produit';
$_MODULE['<{ingpsp}prestashop>ingpsp_7e858f7ae99f1431164a22973eb6ffda'] = 'Kassa Compleet';
$_MODULE['<{ingpsp}prestashop>ingpsp_081d60287de236d7f50b78b00ffa4c34'] = 'ING Checkout';
$_MODULE['<{ingpsp}prestashop>ingpsp_f2a534d504f841d76bf87e1a227db34d'] = 'ING ePay';
$_MODULE['<{ingpsp}prestashop>ingpsp_72050a2fc6b64df39833fe4f0268a334'] = 'Résout le problème lorsque le curl.cacert path n\'est pas défini dans PHP.ini';
$_MODULE['<{ingpsp}prestashop>ingpsp_deb7cb91dd8a3c49c3ee67d71355a561'] = 'Utilisez bundle cURL CA';
$_MODULE['<{ingpsp}prestashop>ingpsp_16192b8b71d2a73adc7a335f0cf4c9e2'] = 'Fournir automatiquement l\'URL Webhook avec la commande à l\'API du ING PSP.';
$_MODULE['<{ingpsp}prestashop>ingpsp_f095af35c2433074509597c4c828f879'] = 'Joinez Webhook URL avec chaque commande.';
$_MODULE['<{ingpsp}prestashop>ingpsp_d876ff8da67c3731ae25d8335a4168b4'] = 'clé API';
$_MODULE['<{ingpsp}prestashop>ingpsp_c33550a3e5e97c7f4bc6552f37e96c97'] = 'clé API de Test';
$_MODULE['<{ingpsp}prestashop>ingpsp_5bb461e1983e238ff34a2256eaea6ef7'] = 'La clé API de Test est valable uniquement pour Klarna. Laissez ce champ vide lorsqu\'il n\'est pas utilisé.';
$_MODULE['<{ingpsp}prestashop>ingpsp_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{ingpsp}prestashop>errors-messages_8e488562a0a85e303af4b1713b9a932e'] = 'Il y a une erreur inattendue de versement. Veuillez reessayer s\'il vous plaît.';
$_MODULE['<{ingpsp}prestashop>errors-messages_471602b1e82c261e19506cfc74b89716'] = 'Il y avait malheureusement un problème traitant votre paiement. Veuillez reessayer le paiement s\'il vous plaît.';
$_MODULE['<{ingpsp}prestashop>errors-messages_34e0a062726d06e24047764c3bef28c0'] = 'Cliquez ici pour réessayer.';
$_MODULE['<{ingpsp}prestashop>pending_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpsp}prestashop>pending_59a536eff179c44dff6f4a87057acc68'] = 'Nous n\'avons pas reçu de confirmation de votre banque ou de votre émetteur de carte de crédit.';
$_MODULE['<{ingpsp}prestashop>pending_d8512d09788452018a064169d2363ca3'] = 'Vous recevrez un message dès que nous l\'aurons reçu.';
$_MODULE['<{ingpsp}prestashop>pending_b1193e98dc69a11033057672c190cc85'] = 'Cliquez ici pour réessayer.';
$_MODULE['<{ingpsp}prestashop>processing_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpsp}prestashop>processing_8b792b5d9eedc14ed033c964f4cb6023'] = 'Veuillez attender pendant votre statut de commande est en cours de vérification.';

