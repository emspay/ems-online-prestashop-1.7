<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_ef71b31fa8895dc2fbd0f437cffbf574'] = 'ING PSP Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_195785cd7a559674bde033a1de76a795'] = 'Accepter les versements en utilisant Home\'Pay dans votre boutique en ligne.';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_cbe0a99684b145e77f3e14174ac212e3'] = 'Êtes-vous sûr de supprimer ces détails?';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_a02758d758e8bec77a33d7f392eb3f8a'] = 'Aucune devise a été définie pour ce module. S\'il vous plaît configurer ce dans le menu Localisations / section Currencies.';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_171e805135cd2492623cd338a7c42a1b'] = 'Payer par Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_7853e11acea9a6109b2f1c00cdb4041e'] = 'Votre commande à';
$_MODULE['<{ingpsphomepay}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpsphomepay}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Il y avait une erreur lors du traitement de votre commande. Nous nous excusons pour le dérangement. Please click here to choose another payment method.	=	Cliquez ici pour choisir une autre méthode de paiement. Go back to the checkout page	=	Retour à la page de paiement.';
$_MODULE['<{ingpsphomepay}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Cliquez ici pour choisir une autre méthode de paiement. ';
$_MODULE['<{ingpsphomepay}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Cliquez ici pour réessayer.';
$_MODULE['<{ingpsphomepay}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Retour vers la page de paiement.';
$_MODULE['<{ingpsphomepay}prestashop>payment_171e805135cd2492623cd338a7c42a1b'] = 'Payer par Home\'Pay.';
$_MODULE['<{ingpsphomepay}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpsphomepay}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Merci beaucoup pour votre commande.';
