<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_ef71b31fa8895dc2fbd0f437cffbf574'] = 'ING PSP Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_195785cd7a559674bde033a1de76a795'] = 'Akzeptiere Zahlungen für Ihre Produkte mit Home\'Pay.';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_cbe0a99684b145e77f3e14174ac212e3'] = 'Sind Sie sicher, diese Details zu entfernen?';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_a02758d758e8bec77a33d7f392eb3f8a'] = 'Keine Währung ist für dieses Modul eingestellt worden. Sie können das einstellen in das Localization / Currencies Menu.';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_171e805135cd2492623cd338a7c42a1b'] = 'Bezahlen bei Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_7853e11acea9a6109b2f1c00cdb4041e'] = 'Ihre Bestellung bei';
$_MODULE['<{ingpsphomepay}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Leider ist ein Fehler bei der Verarbeitung Ihrer Bezahlung aufgetreten.';
$_MODULE['<{ingpsphomepay}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Bitte klick hier um eine andere Zahlungsart zu wahlen.';
$_MODULE['<{ingpsphomepay}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Bitte klicken Sie hier noch einmal zu versuchen.';
$_MODULE['<{ingpsphomepay}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Kehren Sie zurück zur Kassa.';
$_MODULE['<{ingpsphomepay}prestashop>payment_171e805135cd2492623cd338a7c42a1b'] = 'Bezahlen bei Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Ihre bestellung bei %s';
$_MODULE['<{ingpsphomepay}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Herzlichen Dank für Ihre Bestellung.';
