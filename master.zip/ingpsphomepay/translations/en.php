<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_ef71b31fa8895dc2fbd0f437cffbf574'] = 'ING PSP Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_195785cd7a559674bde033a1de76a795'] = 'Accept payments in your webshop using HomePay.';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_cbe0a99684b145e77f3e14174ac212e3'] = 'Are you sure about removing the details?';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_a02758d758e8bec77a33d7f392eb3f8a'] = 'No currency has been set for this module. Please configure this in the Localizations menu/Currencies section.';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_171e805135cd2492623cd338a7c42a1b'] = 'Pay by Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_7853e11acea9a6109b2f1c00cdb4041e'] = 'Your order at';
$_MODULE['<{ingpsphomepay}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = ' Your order at %s';
$_MODULE['<{ingpsphomepay}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'There was an error processing your order. We apologize for the inconvenience.';
$_MODULE['<{ingpsphomepay}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Please click here to choose another payment method.';
$_MODULE['<{ingpsphomepay}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Please click here to try again';
$_MODULE['<{ingpsphomepay}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Go back to the checkout page.';
$_MODULE['<{ingpsphomepay}prestashop>payment_171e805135cd2492623cd338a7c42a1b'] = 'Pay by Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = ' Your order at %s';
$_MODULE['<{ingpsphomepay}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Thank you for your order';
