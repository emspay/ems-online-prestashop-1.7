<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_ef71b31fa8895dc2fbd0f437cffbf574'] = 'ING PSP Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_195785cd7a559674bde033a1de76a795'] = 'Met deze module kunt u Home\'Pay betalingen accepteren.';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_cbe0a99684b145e77f3e14174ac212e3'] = 'Weet u zeker dat u deze gegevens wenst te verwijderen';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_a02758d758e8bec77a33d7f392eb3f8a'] = 'Er is geen valuta ingesteld voor deze module. U kunt dit instellen in het Localization / Currencies menu.';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_171e805135cd2492623cd338a7c42a1b'] = 'Betaal met Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>ingpsphomepay_7853e11acea9a6109b2f1c00cdb4041e'] = 'Uw bestelling bij';
$_MODULE['<{ingpsphomepay}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Uw bestelling bij %s';
$_MODULE['<{ingpsphomepay}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Helaas is er een fout opgetreden tijdens het verwerken van uw betaling.';
$_MODULE['<{ingpsphomepay}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Klik hier om een andere betaalmethode te selecteren.';
$_MODULE['<{ingpsphomepay}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Klik hier om nogmaals te proberen.';
$_MODULE['<{ingpsphomepay}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Keer terug naar de betaalpagina.';
$_MODULE['<{ingpsphomepay}prestashop>payment_171e805135cd2492623cd338a7c42a1b'] = 'Betaal met Home\'Pay';
$_MODULE['<{ingpsphomepay}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Uw bestelling bij %s';
$_MODULE['<{ingpsphomepay}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Dank voor uw bestelling';
