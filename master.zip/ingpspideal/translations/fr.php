<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspideal}prestashop>ingpspideal_dcaeefb2bc12776e03b28e608529849b'] = 'ING PSP iDEAL';
$_MODULE['<{ingpspideal}prestashop>ingpspideal_2ed8049059e1c9e83562c2da2efaa983'] = 'Accepter les versements en utilisant iDEAL dans votre boutique en ligne..';
$_MODULE['<{ingpspideal}prestashop>ingpspideal_cbe0a99684b145e77f3e14174ac212e3'] = 'Êtes-vous sûr de supprimer ces détails?';
$_MODULE['<{ingpspideal}prestashop>ingpspideal_a02758d758e8bec77a33d7f392eb3f8a'] = 'Aucune devise a été définie pour ce module. S\'il vous plaît configurer ce dans le menu Localisations / section Currencies.';
$_MODULE['<{ingpspideal}prestashop>ingpspideal_7481ccc2277cf3116c8e6ce58a9177b3'] = 'Payer par iDEAL';
$_MODULE['<{ingpspideal}prestashop>ingpspideal_7853e11acea9a6109b2f1c00cdb4041e'] = 'Votre commande à';
$_MODULE['<{ingpspideal}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpspideal}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Il y avait une erreur lors du traitement de votre commande. Nous nous excusons pour le dérangement.';
$_MODULE['<{ingpspideal}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Cliquez ici pour choisir une autre méthode de paiement.';
$_MODULE['<{ingpspideal}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Cliquez ici pour réessayer.';
$_MODULE['<{ingpspideal}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Retour vers la page de paiement.';
$_MODULE['<{ingpspideal}prestashop>payment_7481ccc2277cf3116c8e6ce58a9177b3'] = 'Payer par iDEAL';
$_MODULE['<{ingpspideal}prestashop>payment_48fa0f621f79f451e58f200957da5b52'] = 'Choisissez votre banque';
$_MODULE['<{ingpspideal}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpspideal}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Merci beaucoup pour votre commande.';
