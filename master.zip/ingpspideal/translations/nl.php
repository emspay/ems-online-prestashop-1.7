<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspideal}prestashop>ingpspideal_dcaeefb2bc12776e03b28e608529849b'] = 'ING PSP iDEAL';
$_MODULE['<{ingpspideal}prestashop>ingpspideal_2ed8049059e1c9e83562c2da2efaa983'] = 'Met deze module kunt u iDEAL betalingen accepteren. ';
$_MODULE['<{ingpspideal}prestashop>ingpspideal_cbe0a99684b145e77f3e14174ac212e3'] = 'Weet u zeker dat u deze gegevens wenst te verwijderen';
$_MODULE['<{ingpspideal}prestashop>ingpspideal_a02758d758e8bec77a33d7f392eb3f8a'] = 'Er is geen valuta ingesteld voor deze module. U kunt dit instellen in het Localization / Currencies menu.';
$_MODULE['<{ingpspideal}prestashop>ingpspideal_7481ccc2277cf3116c8e6ce58a9177b3'] = 'Betaal met iDEAL';
$_MODULE['<{ingpspideal}prestashop>ingpspideal_7853e11acea9a6109b2f1c00cdb4041e'] = 'Uw bestelling bij';
$_MODULE['<{ingpspideal}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Uw bestelling bij %s';
$_MODULE['<{ingpspideal}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Helaas is er een fout opgetreden tijdens het verwerken van uw betaling. Onze excuses voor het ongemak.';
$_MODULE['<{ingpspideal}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Klik hier om een andere betaalmethode te selecteren.';
$_MODULE['<{ingpspideal}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Klik hier om nogmaals te proberen.';
$_MODULE['<{ingpspideal}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Keer terug naar de betaalpagina.';
$_MODULE['<{ingpspideal}prestashop>payment_7481ccc2277cf3116c8e6ce58a9177b3'] = 'Betaal met iDEAL';
$_MODULE['<{ingpspideal}prestashop>payment_48fa0f621f79f451e58f200957da5b52'] = 'Kies uw bank';
$_MODULE['<{ingpspideal}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Uw bestelling bij %s';
$_MODULE['<{ingpspideal}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Dank voor uw bestelling.';
