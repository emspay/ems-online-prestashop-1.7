<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_04268e26552e537b1fc275641b248613'] = 'ING PSP AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_88263eae6aa4291afb8d2c08e96555b8'] = 'Accepter les versements en utilisant AfterPay dans votre boutique.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_b09c67977572a1f9c8bea1f92a388d4b'] = 'Paramètres du ING PSP';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_56af9b52b08f15a62ff06112edd7e4d2'] = 'L\'adresse IP pour tester le methode du paiement.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_bcf1ecb8263994876e86706f70205200'] = 'Vous pouvez spécifier des adresses IP spécifiques pour lesquelles AfterPay est visible, par exemple si vous souhaitez tester AfterPay, vous pouvez saisir des adresses IP comme 128.0.0.1, 255.255.255.255. Si vous remplissez rien, alors, AfterPay est visible à toutes les adresses IP.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_57dfa2850a7497291f013e49ee184a44'] = 'Payer par AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_7c3b0b7e5a45e86906205db0b6b1ed75'] = 'Malheureusement, vous ne pouvez pas utiliser AfterPay car Afterpay est suelement disponible pour les adresses aux Pays-Bas et en Belgique.S\'il vous plaît utiliser l\'adresse correcte ou sélectionnez un autre mode de paiement.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_7853e11acea9a6109b2f1c00cdb4041e'] = 'Votre commande à';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_55cfb4fea6d0f68ef411d76c6e2f5ad9'] = 'Nous sommes désolés de vous informer que votre demande de payer plus tard ne peut pas être acceptée par Afterpay. Cela aurait pu être causé par diverses raisons (temporaires). Si vous avez des questions concernant votre refus, s\'il vous plaît contacter le Service clientèle Afterpay via https://www.afterpay.nl/en/customers/contact ou par téléphone via +31 20 72 30 270. Nous vous conseillons de choisir une autre mode de paiement pour effectuer votre commande.';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_34e0a062726d06e24047764c3bef28c0'] = 'Cliquez ici pour réessayer';
$_MODULE['<{ingpspafterpay}prestashop>payment_9e0f0cf5c70444031ed87782ba3422b2'] = 'J\'accepte AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>payment_1d8cd2bfc6943dcf70236f7d351572a0'] = 'Termes et conditions';
$_MODULE['<{ingpspafterpay}prestashop>payment_6a1c0ea4d3b789b3025a73cd977b4a7a'] = 'SVP Acceptez les termes et conditions';
$_MODULE['<{ingpspafterpay}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpspafterpay}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Le paiement en utilisant AfterPay est réussie.';
