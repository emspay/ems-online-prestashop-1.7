<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_04268e26552e537b1fc275641b248613'] = 'ING PSP AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_88263eae6aa4291afb8d2c08e96555b8'] = 'Akzeptiere Zahlungen für Ihre Produkte mit AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_b09c67977572a1f9c8bea1f92a388d4b'] = 'ING PSP Einstellungen';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_56af9b52b08f15a62ff06112edd7e4d2'] = 'IP-Adresse(n) für Prüfung.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_bcf1ecb8263994876e86706f70205200'] = 'Sie können spezifische IP-Adressen angeben, für die AfterPay sichtbar ist, zB wenn Sie AfterPay testen möchten, können Sie IP-Adressen als 128.0.0.1, 255.255.255.255 eingeben. Wenn Sie nichts ausfüllen, dann ist AfterPay für alle IP-Adressen sichtbar.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_57dfa2850a7497291f013e49ee184a44'] = 'Bezahlen mit AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_7c3b0b7e5a45e86906205db0b6b1ed75'] = 'Leider können Sie AfterPay nicht verwenden, da Afterpay nur für Adressen in den Niederlanden und Belgien verfügbar ist. Bitte verwenden Sie die richtige Adresse oder eine andere Zahlungsmethode wählen.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_7853e11acea9a6109b2f1c00cdb4041e'] = 'Ihre Bestellung bei';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_68a489dbc8079a40832c3d558fcfb069'] = 'Ihre Bestellung bei %s';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_55cfb4fea6d0f68ef411d76c6e2f5ad9'] = 'We are sorry to inform you that your request to pay afterwards cannot be accepted by Afterpay. This could have been caused by various (temporary) reasons. If you have any questions pertaining to your rejection, please contact the Afterpay Customer Service via link https://www.afterpay.nl/en/customers/contact or by phone via +31 20 72 30 270. We advise you to select another payment method to complete the payment of your order.';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_34e0a062726d06e24047764c3bef28c0'] = 'Bitte klicken Sie hier noch einmal zu versuchen.';
$_MODULE['<{ingpspafterpay}prestashop>payment_9e0f0cf5c70444031ed87782ba3422b2'] = 'Ich akzeptiere AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>payment_1d8cd2bfc6943dcf70236f7d351572a0'] = 'Nutzungsbedingungen';
$_MODULE['<{ingpspafterpay}prestashop>payment_6a1c0ea4d3b789b3025a73cd977b4a7a'] = 'Bitte akzeptieren Sie die Nutzungsbedingungen';
$_MODULE['<{ingpspafterpay}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Ihre Bestellung bei %s';
$_MODULE['<{ingpspafterpay}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Vielen Dank für Ihre Bestellung. Ihre Bezahlung ist erfolgreich abgeschlossen.';
