<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_04268e26552e537b1fc275641b248613'] = 'ING PSP AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_88263eae6aa4291afb8d2c08e96555b8'] = 'Met deze module kunt u AfterPay betalingen accepteren.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen aangepast';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_b09c67977572a1f9c8bea1f92a388d4b'] = 'ING PSP Instellingen';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_56af9b52b08f15a62ff06112edd7e4d2'] = 'IP adres(sen) voor testen';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_bcf1ecb8263994876e86706f70205200'] = 'U kunt specifieke IP adressen opgeven waarvoor de betaalmethode AfterPay zichtbaar is, bv als u wilt testen (bijvoorbeeld: 128.0.0.1, 255.255.255.255). Vult u niets in dan is AfterPay voor alle IP adressen zichtbaar.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_57dfa2850a7497291f013e49ee184a44'] = 'Betalen met AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_7c3b0b7e5a45e86906205db0b6b1ed75'] = 'Helaas kunt u AfterPay niet gebruiken omdat AfterPay alleen beschikbaar is voor adressen in Nederland en België. Gebruik alstublieft het juiste adres of selecteer een andere betaalmethode.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_7853e11acea9a6109b2f1c00cdb4041e'] = 'Uw bestelling bij';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_68a489dbc8079a40832c3d558fcfb069'] = 'Uw bestelling bij %s';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_55cfb4fea6d0f68ef411d76c6e2f5ad9'] = 'Het spijt ons u te moeten mededelen dat uw aanvraag om uw bestelling achteraf te betalen op dit moment niet door AfterPay wordt geaccepteerd. Dit kan om diverse (tijdelijke) redenen zijn.Voor vragen over uw afwijzing kunt u contact opnemen met de Klantenservice van AfterPay. Of kijk op de website van AfterPay bij \"Veel gestelde vragen\" via de link http://www.afterpay.nl/page/consument-faq onder het kopje \"Gegevenscontrole\". Wij adviseren u voor een andere betaalmethode te kiezen om alsnog de betaling van uw bestelling af te ronden.';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_34e0a062726d06e24047764c3bef28c0'] = 'Klik hier om nogmaals te proberen.';
$_MODULE['<{ingpspafterpay}prestashop>payment_9e0f0cf5c70444031ed87782ba3422b2'] = 'Ik accepteer AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>payment_1d8cd2bfc6943dcf70236f7d351572a0'] = 'Gebruiksvoorwaarden';
$_MODULE['<{ingpspafterpay}prestashop>payment_6a1c0ea4d3b789b3025a73cd977b4a7a'] = 'AUB de algemene voorwaarden accepteren';
$_MODULE['<{ingpspafterpay}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Uw bestelling bij %s';
$_MODULE['<{ingpspafterpay}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Dank voor uw bestelling. Uw betaling is succesvol verwerkt.';
