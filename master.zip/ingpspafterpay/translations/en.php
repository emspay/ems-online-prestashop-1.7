<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_04268e26552e537b1fc275641b248613'] = 'ING PSP AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_88263eae6aa4291afb8d2c08e96555b8'] = 'Accept payments for your products using ING PSP AfterPay     ';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_c888438d14855d7d96a2724ee9c306bd'] = 'Settings have been updated.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_b09c67977572a1f9c8bea1f92a388d4b'] = 'ING PSP Settings';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_56af9b52b08f15a62ff06112edd7e4d2'] = 'IP address(es) for testing.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_bcf1ecb8263994876e86706f70205200'] = 'You can specify specific IP addresses for which AfterPay is visible, for example if you want to test AfterPay you can type IP addresses as 128.0.0.1, 255.255.255.255. If you fill in nothing, then, AfterPay is visible to all IP addresses.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_57dfa2850a7497291f013e49ee184a44'] = 'Pay by AfterPay';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_7c3b0b7e5a45e86906205db0b6b1ed75'] = 'Unfortunately, you cannot use AfterPay as Afterpay is only available for addresses in the Netherlands and Belgium. Please use the correct address or select another payment method.';
$_MODULE['<{ingpspafterpay}prestashop>ingpspafterpay_7853e11acea9a6109b2f1c00cdb4041e'] = 'Your order at';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_68a489dbc8079a40832c3d558fcfb069'] = 'Your order at %s';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_55cfb4fea6d0f68ef411d76c6e2f5ad9'] = 'We are sorry to inform you that your request to pay afterwards cannot be accepted by Afterpay. This could have been caused by various (temporary) reasons. If you have any questions pertaining to your rejection, please contact the Afterpay Customer Service via link https://www.afterpay.nl/en/customers/contact or by phone via +31 20 72 30 270. We advise you to select another payment method to complete the payment of your order.';
$_MODULE['<{ingpspafterpay}prestashop>cancelled_34e0a062726d06e24047764c3bef28c0'] = 'Please click here to try again.   ';
$_MODULE['<{ingpspafterpay}prestashop>payment_9e0f0cf5c70444031ed87782ba3422b2'] = 'I accept AfterPay	';
$_MODULE['<{ingpspafterpay}prestashop>payment_1d8cd2bfc6943dcf70236f7d351572a0'] = 'Terms & Conditions';
$_MODULE['<{ingpspafterpay}prestashop>payment_6a1c0ea4d3b789b3025a73cd977b4a7a'] = 'Please accept Afterpay Terms & Conditions';
$_MODULE['<{ingpspafterpay}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Your order at %s';
$_MODULE['<{ingpspafterpay}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Thank you for your order. Your payment using AfterPay is successful.';
