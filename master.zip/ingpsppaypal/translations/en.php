<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_fe33fe7b15e1f8dbc4bf8466a8c08ba2'] = 'ING PSP PayPal';
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_a996e6373c03cd2d6daeecdd4e1eb725'] = 'Accept payments in your webshop using PayPal.';
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_cbe0a99684b145e77f3e14174ac212e3'] = 'Are you sure about removing those details?';
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_a02758d758e8bec77a33d7f392eb3f8a'] = 'No currency has been set for this module. Please configure this in the Localizations menu/Currencies section.';
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_19ef08887745e7b9e37ea8c46849e592'] = 'Pay by PayPal';
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_7853e11acea9a6109b2f1c00cdb4041e'] = 'Your order at';
$_MODULE['<{ingpsppaypal}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = ' Your order at %s';
$_MODULE['<{ingpsppaypal}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'There was an error processing your order. We apologize for the inconvenience.';
$_MODULE['<{ingpsppaypal}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Please click here to choose another payment method.';
$_MODULE['<{ingpsppaypal}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Please click here to try again';
$_MODULE['<{ingpsppaypal}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Go back to the checkout page.';
$_MODULE['<{ingpsppaypal}prestashop>payment_19ef08887745e7b9e37ea8c46849e592'] = 'Pay by PayPal';
$_MODULE['<{ingpsppaypal}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = ' Your order at %s';
$_MODULE['<{ingpsppaypal}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Thank you for your order';
