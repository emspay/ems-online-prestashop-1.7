<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_fe33fe7b15e1f8dbc4bf8466a8c08ba2'] = 'ING PSP PayPal';
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_a996e6373c03cd2d6daeecdd4e1eb725'] = 'Accepter les versements en utilisant PayPal dans votre boutique en ligne.';
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_cbe0a99684b145e77f3e14174ac212e3'] = 'Êtes-vous sûr de supprimer ces détails?';
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_a02758d758e8bec77a33d7f392eb3f8a'] = 'Aucune devise a été définie pour ce module. S\'il vous plaît configurer ce dans le menu Localisations / section Currencies.';
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_19ef08887745e7b9e37ea8c46849e592'] = 'Payer par PayPal';
$_MODULE['<{ingpsppaypal}prestashop>ingpsppaypal_7853e11acea9a6109b2f1c00cdb4041e'] = 'Votre commande à';
$_MODULE['<{ingpsppaypal}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpsppaypal}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Il y avait une erreur lors du traitement de votre commande. Nous nous excusons pour le dérangement.';
$_MODULE['<{ingpsppaypal}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Cliquez ici pour choisir une autre méthode de paiement.';
$_MODULE['<{ingpsppaypal}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Cliquez ici pour réessayer.';
$_MODULE['<{ingpsppaypal}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Retour vers la page de paiement.';
$_MODULE['<{ingpsppaypal}prestashop>payment_19ef08887745e7b9e37ea8c46849e592'] = 'Payer par PayPal';
$_MODULE['<{ingpsppaypal}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpsppaypal}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Merci beaucoup pour votre commande.';
