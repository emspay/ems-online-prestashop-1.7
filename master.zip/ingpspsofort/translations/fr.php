<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspsofort}prestashop>ingpspsofort_4e14356078492e74bd9db7b73ca7c59a'] = 'ING PSP SOFORT';
$_MODULE['<{ingpspsofort}prestashop>ingpspsofort_f34a3858b182ac360b1f979670db1af6'] = 'Accepter les versements en utilisant SOFORT dans votre boutique en ligne.';
$_MODULE['<{ingpspsofort}prestashop>ingpspsofort_cbe0a99684b145e77f3e14174ac212e3'] = 'Êtes-vous sûr de supprimer ces détails?';
$_MODULE['<{ingpspsofort}prestashop>ingpspsofort_a02758d758e8bec77a33d7f392eb3f8a'] = 'Aucune devise a été définie pour ce module. S\'il vous plaît configurer ce dans le menu Localisations / section Currencies.';
$_MODULE['<{ingpspsofort}prestashop>ingpspsofort_068bcd34a6ded96b1805ca0b9a6745bb'] = 'Payer par SOFORT';
$_MODULE['<{ingpspsofort}prestashop>ingpspsofort_7853e11acea9a6109b2f1c00cdb4041e'] = 'Votre commande à';
$_MODULE['<{ingpspsofort}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpspsofort}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Il y avait une erreur lors du traitement de votre commande. Nous nous excusons pour le dérangement.';
$_MODULE['<{ingpspsofort}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Cliquez ici pour choisir une autre méthode de paiement.';
$_MODULE['<{ingpspsofort}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Cliquez ici pour réessayer.';
$_MODULE['<{ingpspsofort}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Retour vers la page de paiement.';
$_MODULE['<{ingpspsofort}prestashop>payment_068bcd34a6ded96b1805ca0b9a6745bb'] = 'Payer par SOFORT';
$_MODULE['<{ingpspsofort}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpspsofort}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Merci beaucoup pour votre commande.';
