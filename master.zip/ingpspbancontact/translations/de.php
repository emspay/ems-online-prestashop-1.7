<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_0145bccab6a0bf9434dbac0394e839f3'] = 'ING PSP Bancontact';
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_97348bde8427d75a39530b746a85219f'] = 'Akzeptiere Zahlungen für Ihre Produkte mit Bancontact.';
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_cbe0a99684b145e77f3e14174ac212e3'] = 'Sind Sie sicher, diese Details zu entfernen?';
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_a02758d758e8bec77a33d7f392eb3f8a'] = 'Keine Währung ist für dieses Modul eingestellt worden. Sie können das einstellen in das Localization / Currencies Menu.';
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_d536f6cb1304cde5da44c530d3157886'] = 'Bezahlen mit Bancontact';
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_7853e11acea9a6109b2f1c00cdb4041e'] = 'Ihre Bestellung bei';
$_MODULE['<{ingpspbancontact}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Ihre bestellung bei %s';
$_MODULE['<{ingpspbancontact}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Leider ist ein Fehler bei der Verarbeitung Ihrer Bezahlung aufgetreten.';
$_MODULE['<{ingpspbancontact}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Bitte klick hier um eine andere Zahlungsart zu wahlen.';
$_MODULE['<{ingpspbancontact}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Bitte klicken Sie hier noch einmal zu versuchen.';
$_MODULE['<{ingpspbancontact}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Kehren Sie zurück zur Kassa.';
$_MODULE['<{ingpspbancontact}prestashop>payment_d536f6cb1304cde5da44c530d3157886'] = 'Bezahlen mit Bancontact';
$_MODULE['<{ingpspbancontact}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Ihre bestellung bei %s';
$_MODULE['<{ingpspbancontact}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Vielen Dank für Ihre Bestellung';
