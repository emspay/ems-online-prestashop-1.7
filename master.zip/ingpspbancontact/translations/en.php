<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_0145bccab6a0bf9434dbac0394e839f3'] = 'ING PSP Bancontact';
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_97348bde8427d75a39530b746a85219f'] = 'Accept payments in your webshop using Bancontact';
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_cbe0a99684b145e77f3e14174ac212e3'] = 'Are you sure about removing these details?';
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_a02758d758e8bec77a33d7f392eb3f8a'] = 'No currency has been set for this module. Please configure this in the Localizations menu/Currencies section.';
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_d536f6cb1304cde5da44c530d3157886'] = 'Pay by Bancontact';
$_MODULE['<{ingpspbancontact}prestashop>ingpspbancontact_7853e11acea9a6109b2f1c00cdb4041e'] = 'Your order at';
$_MODULE['<{ingpspbancontact}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = ' Your order at %s';
$_MODULE['<{ingpspbancontact}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'There was an error processing your order. We apologize for the inconvenience.';
$_MODULE['<{ingpspbancontact}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Please click here to choose another payment method.';
$_MODULE['<{ingpspbancontact}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Please click here to try again.';
$_MODULE['<{ingpspbancontact}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Go back to the Checkout page.';
$_MODULE['<{ingpspbancontact}prestashop>payment_d536f6cb1304cde5da44c530d3157886'] = 'Pay by Bancontact';
$_MODULE['<{ingpspbancontact}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = ' Your order at %s';
$_MODULE['<{ingpspbancontact}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Thank you for your order';
