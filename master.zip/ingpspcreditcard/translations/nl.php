<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspcreditcard}prestashop>ingpspcreditcard_6db82dddb37a6285b43e419ca64ca423'] = 'ING PSP Creditcard';
$_MODULE['<{ingpspcreditcard}prestashop>ingpspcreditcard_1f85d0dc4f3c772b9a8f3432eeed98b3'] = 'Met deze module kunt u Creditcard betalingen accepteren.';
$_MODULE['<{ingpspcreditcard}prestashop>ingpspcreditcard_cbe0a99684b145e77f3e14174ac212e3'] = 'Weet u zeker dat u deze details wilt verwijderen?';
$_MODULE['<{ingpspcreditcard}prestashop>ingpspcreditcard_a02758d758e8bec77a33d7f392eb3f8a'] = 'Er is geen valuta ingesteld voor deze module. U kunt dit instellen in het Localization / Currencies menu.';
$_MODULE['<{ingpspcreditcard}prestashop>ingpspcreditcard_a3a724bde2f6f3dd84962b3908081e7b'] = 'Betalen met  Mastercard, VISA, Maestro of V PAY';
$_MODULE['<{ingpspcreditcard}prestashop>ingpspcreditcard_7853e11acea9a6109b2f1c00cdb4041e'] = 'Uw bestelling bij';
$_MODULE['<{ingpspcreditcard}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Uw bestelling bij %s';
$_MODULE['<{ingpspcreditcard}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Helaas is er een fout opgetreden tijdens het verwerken van uw betaling. Onze excuses voor het ongemak.';
$_MODULE['<{ingpspcreditcard}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Klik hier om een andere betaalmethode te selecteren.';
$_MODULE['<{ingpspcreditcard}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Klik hier om nogmaals te proberen.';
$_MODULE['<{ingpspcreditcard}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Keer terug naar de betaalpagina.';
$_MODULE['<{ingpspcreditcard}prestashop>payment_a3a724bde2f6f3dd84962b3908081e7b'] = 'Betaal met Mastercard, VISA, Maestro of V PAY';
$_MODULE['<{ingpspcreditcard}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Uw bestelling bij %s';
$_MODULE['<{ingpspcreditcard}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Dank voor uw bestelling.';
