<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_186d247711913a65fa6dde5b32e9b83d'] = 'ING PSP Nachnahme';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_241d302d0eadb60f2ac7bc520f59140b'] = 'Akzeptiere Zahlungen für Ihre Produkte mit Nachnahme';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_cbe0a99684b145e77f3e14174ac212e3'] = 'Sind Sie sicher, diese Details zu entfernen?';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_a02758d758e8bec77a33d7f392eb3f8a'] = 'Keine Währung ist für dieses Modul eingestellt worden. Sie können das einstellen in das Localization / Currencies Menu.';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_4d5bc3db88308a4f260eac33298e6596'] = 'Bezahlen mit Nachnahme';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_7853e11acea9a6109b2f1c00cdb4041e'] = 'Ihre Bestellung bei';
$_MODULE['<{ingpspcashondelivery}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Ihre bestellung bei %s';
$_MODULE['<{ingpspcashondelivery}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Leider ist ein Fehler bei der Verarbeitung Ihrer Bezahlung aufgetreten.';
$_MODULE['<{ingpspcashondelivery}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Bitte klick hier um eine andere Zahlungsart zu wahlen.';
$_MODULE['<{ingpspcashondelivery}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Bitte klicken Sie hier noch einmal zu versuchen.';
$_MODULE['<{ingpspcashondelivery}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Kehren Sie zurück zur Kassa.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_4d5bc3db88308a4f260eac33298e6596'] = 'Bezahlen mit Nachnahme';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Ihre bestellung bei %s';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_88526efe38fd18179a127024aba8c1d7'] = 'Ihre Bestellung auf %s ist komplett.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_8861c5d3fa54b330d1f60ba50fcc4aab'] = 'Sie haben die nachnahme methode gewählt.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_e6dc7945b557a1cd949bea92dd58963e'] = 'Ihre Bestellung wird schnellstmöglich verschickt.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_0db71da7150c27142eef9d22b843b4a9'] = 'Wenn Sie Fragen haben nehmenhaben nehmen Sie bitte Kontakt mit unseren';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_64430ad2835be8ad60c59e7d44e4b0b1'] = 'Kundendienst';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_a721a0b7912341d2a8c7fca874d78095'] = 'Wir haben ein Problem mit Ihrer Bestellung bemerkt. Nehmen Sie bitte Kontakt mit uns auf.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_0b3b97fa66886c5688ee4ae80ec0c3c2'] = 'uns';
