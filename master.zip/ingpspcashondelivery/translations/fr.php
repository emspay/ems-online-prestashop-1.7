<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_186d247711913a65fa6dde5b32e9b83d'] = 'ING PSP Contre-remboursement';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_241d302d0eadb60f2ac7bc520f59140b'] = 'Accepter les versements en utilisant Contre-remboursement dans votre boutique en ligne.';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_cbe0a99684b145e77f3e14174ac212e3'] = 'Êtes-vous sûr de supprimer ces détails?';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_a02758d758e8bec77a33d7f392eb3f8a'] = 'Aucune devise a été définie pour ce module. S\'il vous plaît configurer ce dans le menu Localisations / section Currencies.';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_4d5bc3db88308a4f260eac33298e6596'] = 'Payer par Contre-remboursement';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_7853e11acea9a6109b2f1c00cdb4041e'] = 'Votre commande à';
$_MODULE['<{ingpspcashondelivery}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpspcashondelivery}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Il y avait une erreur lors du traitement de votre commande. Nous nous excusons pour le dérangement.';
$_MODULE['<{ingpspcashondelivery}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Cliquez ici pour choisir une autre méthode de paiement.';
$_MODULE['<{ingpspcashondelivery}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Cliquez ici pour réessayer.';
$_MODULE['<{ingpspcashondelivery}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Retour vers la page de paiement.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_4d5bc3db88308a4f260eac33298e6596'] = 'Payer par Contre-remboursement';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_88526efe38fd18179a127024aba8c1d7'] = 'Votre commande sur %s est complète .';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_8861c5d3fa54b330d1f60ba50fcc4aab'] = 'Vous avez choisi Contre-remboursement.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_e6dc7945b557a1cd949bea92dd58963e'] = 'Votre commande vous sera envoyée bientôt';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_0db71da7150c27142eef9d22b843b4a9'] = 'Pour toute questions , contactez notre';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_64430ad2835be8ad60c59e7d44e4b0b1'] = 'Service clientèle';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_a721a0b7912341d2a8c7fca874d78095'] = 'Nous avons remarqué un problème avec votre commande. S\'il vous plaït nous contactez';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_0b3b97fa66886c5688ee4ae80ec0c3c2'] = 'nous';
