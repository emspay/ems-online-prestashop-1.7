<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_186d247711913a65fa6dde5b32e9b83d'] = 'ING PSP Rembours';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_241d302d0eadb60f2ac7bc520f59140b'] = 'Met deze module kunt u rembours betalingen accepteren.';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_cbe0a99684b145e77f3e14174ac212e3'] = 'Weet u zeker dat u deze details wilt verwijderen?';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_a02758d758e8bec77a33d7f392eb3f8a'] = 'Er is geen valuta ingesteld voor deze module. U kunt dit instellen in het Localization / Currencies menu.';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_4d5bc3db88308a4f260eac33298e6596'] = 'Betalen met Rembours';
$_MODULE['<{ingpspcashondelivery}prestashop>ingpspcashondelivery_7853e11acea9a6109b2f1c00cdb4041e'] = 'Uw bestelling bij';
$_MODULE['<{ingpspcashondelivery}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Uw bestelling bij %s';
$_MODULE['<{ingpspcashondelivery}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Helaas is er een fout opgetreden tijdens het verwerken van uw betaling. Onze excuses voor het ongemak.';
$_MODULE['<{ingpspcashondelivery}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Klik hier om een andere betaalmethode te selecteren.';
$_MODULE['<{ingpspcashondelivery}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Klik hier om nogmaals te proberen.';
$_MODULE['<{ingpspcashondelivery}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Keer terug naar de betaalpagina.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_4d5bc3db88308a4f260eac33298e6596'] = 'Betaal met Rembours';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Uw bestelling bij %s';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_88526efe38fd18179a127024aba8c1d7'] = 'Uw betaling bij %s is afgerond.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_8861c5d3fa54b330d1f60ba50fcc4aab'] = 'U heeft gekozen te betalen onder rembours.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_e6dc7945b557a1cd949bea92dd58963e'] = 'Uw order wordt zo spoedig mogelijk verzonden.';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_0db71da7150c27142eef9d22b843b4a9'] = 'Voor verdere vragen, neemt u contact op met onze';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_64430ad2835be8ad60c59e7d44e4b0b1'] = 'klantenservice';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_a721a0b7912341d2a8c7fca874d78095'] = 'Er ging iets fout met uw order, als u denkt dat dit onterecht is, neem dan contact op met';
$_MODULE['<{ingpspcashondelivery}prestashop>payment_return_0b3b97fa66886c5688ee4ae80ec0c3c2'] = 'ons';
