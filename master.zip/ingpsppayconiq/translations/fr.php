<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ingpsppayconiq}prestashop>ingpsppayconiq_a89bbc5d2f9ded627390eb292959a72a'] = 'ING PSP Payconiq';
$_MODULE['<{ingpsppayconiq}prestashop>ingpsppayconiq_c54784f5482ada9e0861665dc69d3ac8'] = 'Accepter les versements en utilisant Payconiq dans votre boutique en ligne.';
$_MODULE['<{ingpsppayconiq}prestashop>ingpsppayconiq_39c158c1be55a91bc7d21d06253ae4cf'] = 'Payer par Payconiq';
$_MODULE['<{ingpsppayconiq}prestashop>ingpsppayconiq_a02758d758e8bec77a33d7f392eb3f8a'] = 'Aucune devise a été définie pour ce module. S\'il vous plaît configurer ce dans le menu Localisations / section Currencies.';
$_MODULE['<{ingpsppayconiq}prestashop>ingpsppayconiq_e58b17c25dbd18daa157d79957e8910c'] = 'Payer par Payconiq';
$_MODULE['<{ingpsppayconiq}prestashop>ingpsppayconiq_7853e11acea9a6109b2f1c00cdb4041e'] = 'Votre commande à';
$_MODULE['<{ingpsppayconiq}prestashop>error_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpsppayconiq}prestashop>error_5023dbc72719b0d03162a18fda6db2b3'] = 'Il y avait une erreur lors du traitement de votre commande. Nous nous excusons pour le dérangement.';
$_MODULE['<{ingpsppayconiq}prestashop>error_7dc1ee1a41f69f4027a773780c058b07'] = 'Cliquez ici pour choisir une autre méthode de paiement.';
$_MODULE['<{ingpsppayconiq}prestashop>error_34e0a062726d06e24047764c3bef28c0'] = 'Cliquez ici pour réessayer.';
$_MODULE['<{ingpsppayconiq}prestashop>error_b260f74ed85604be0f0381ce059f6b44'] = 'Retour vers la page de paiement.';
$_MODULE['<{ingpsppayconiq}prestashop>payment_e58b17c25dbd18daa157d79957e8910c'] = 'Payer par Payconiq';
$_MODULE['<{ingpsppayconiq}prestashop>payment_return_68a489dbc8079a40832c3d558fcfb069'] = 'Votre commande à %s';
$_MODULE['<{ingpsppayconiq}prestashop>payment_return_0f9b4be6207d496fc281b0cce2eeed3b'] = 'Merci beaucoup pour votre commande.';
